package com.library.customerinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
